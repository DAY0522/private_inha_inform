#include <iostream>
#include <iomanip>
#include <vector>
using namespace std;

#include "Package.h"
#include "OvernightPackage.h"
#include "TwoDayPackage.h"

int main() {

    vector < Package* > packages(3);

    User A1 = { "Lou Brown", "1 Main St.", "Boston", "MA", "11111" };
    User A2 = { "Mary Smith", "7 Elm St.", "New York", "NY", "22222" };

    User B1 = { "Lisa Klein", "5 Broadway", "Somerville", "MA", "33333" };
    User B2 = { "Bob George", "21 Pine Rd.", "Cambridge", "MA", "44444" };

    User C1 = { "Ed Lewis", "2 Oak St.", "Boston", "MA", "55555" };
    User C2 = { "Don Kelly", "9 Main St.", "Denver", "CO", "66666" };

    packages[0] = new Package(A1, B2, 8.5, .5);
    packages[1] = new TwoDayPackage(B1, B2, 10.5, .65, 2.0); 
    packages[2] = new OvernightPackage(C1, C2, 12.25, 0.7, 0.25); 

    double totalShippingCost = 0.0;

    cout << fixed << setprecision(2);

    for (size_t i = 0; i < packages.size(); i++)
    {
        cout << "Package" << i + 1;
        cout << "\nSender \n";
            cout << "sender name: " << packages[i]->get_sender().name << endl
            << "sender address : " << packages[i]->get_sender().address << endl
            << "sender city : " << packages[i]->get_sender().city << endl
            << "sender state: " << packages[i]->get_sender().state << endl
            << "sender zipcode : " << packages[i]->get_sender().zipCode << endl;


        cout << "\n\nRecipient \n";
        cout << "recipient name: " << packages[i]->get_recipient().name << endl << 
        "recipient address : " << packages[i]->get_recipient().address << endl
            << "recipient city : " << packages[i]->get_recipient().city << endl
            << "recipient state : " << packages[i]->get_recipient().state << endl
            << "recipient zipcode : " << packages[i]->get_recipient().zipCode << endl;
    
        double cost = packages[i]->total_cost();
        cout << "\n\nCost : $" << cost << endl << endl;
        totalShippingCost += cost;
    }
    cout << "Total Shipping Cost : $" << totalShippingCost << endl;
    return 0;
}